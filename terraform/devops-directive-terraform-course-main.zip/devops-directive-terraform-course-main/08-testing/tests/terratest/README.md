How to run this test?

download dependencies, then run the tests...
```
go mod download
go test -v --timeout 10m
```
