Warning about manually switching environments
```
terraform workspace new production
terraform workspace list
terraform workspace select staging
```